import java.io.*;
import java.net.*;
import java.sql.SQLException;
import java.util.ArrayList;


class encodingtaskClient {


    // this method takes the two indexes and a list, and returns the new list that contains
    // all the elements from the initial input list bounded by the two indexes (upper and lower limit included).
    public static ArrayList<String> listadding(int index1, int index2, ArrayList<String> list){

            ArrayList<String> theList = new ArrayList<>();

            for (int i = index1; i <= index2; i++) {
                theList.add(list.get(i));
            }

            return theList;
        }

    public static byte [] listToBytes(ArrayList<String> frame){ // this converts an array into byte array.

        byte[] frameBytes = new byte[frame.size()];

        for (int i = 0; i<frame.size(); i++){

            frameBytes[i] = (byte) Integer.parseInt(frame.get(i), 16);
        }

        return frameBytes;

    }

    public static void main(String[] args) throws IOException, SQLException{
        
        // host and the port through which the client and server are connected
        String host = "localhost";
        int port = 4320;
        
    try {

        FileInputStream file = new FileInputStream("sample-input-ascii.bin"); // data type that allows reading the .bin file
        int i = 0; // variable for reading the file
        
        Socket s = new Socket(host, port);
        // pipelines for communicating between the clien and server
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        DataInputStream dis = new DataInputStream(s.getInputStream());

        String welcomeMessage = dis.readUTF(); // the message from the server that the connection has been established.
        System.out.println(welcomeMessage);
        
        ArrayList<String> hexList = new ArrayList<>(); // list for storing bytes from the .bin file.

        while (true) {

            i = file.read(); // each iteration, one byte is read

            if (i != -1){ // until the EOF is reached, every byte is turned into a hex and added into an Array.
                String hex = String.format("%02X", i);
                hexList.add(hex);
            }

            else{
                
                break;
            }
        }

        // starting indexes for the header - first two bytes.
        int index1 = 0;
        int index2 = 1;

        int hexListLength = hexList.size();

        while(hexListLength != 0){

                if (hexListLength<2){ // if the header is truncated.
                    throw new IOException("Truncated header");
                }
                String header = hexList.get(index1) + hexList.get(index2); // a string that is a header
                int lengthToTake = Integer.parseInt(header, 16); // converts a string from base 16 to a decimal integer

                if (lengthToTake>hexListLength-2){ // if the payload is truncated
                    throw new IOException("Truncated payload");
                }

                if (lengthToTake < 1 || lengthToTake > 4096) { // Payload length check
                    throw new IOException("Invalid payload length: " + lengthToTake);
                }
                
                index2 += lengthToTake; //

                ArrayList<String> frame = listadding(index1, index2, hexList); // we use the method from above and take both the header and the payload.
                index1 += lengthToTake;
                index1 += 2; // now index1 starts after the final element of the payload
                index2 += 2; // index 2 is next to index1 - new header => everything is set for the next iteration.
                hexListLength -= lengthToTake;
                hexListLength -= 2; // both the payload and the header length were taken, so that the loop ends when all the elements are gone through

                byte [] frameBytes = listToBytes(frame); // each frame is converted into byte []
                dos.write(frameBytes); // every frame is sent each iteration one at a time to the server.    
        }

        dos.flush();
        s.shutdownOutput();

    } catch (FileNotFoundException e) { // case when the file is not found

        System.out.println("File not found");

    } catch (IOException e){ // all other error handlings 

        System.out.println(e.getMessage());
    }

    }
} 