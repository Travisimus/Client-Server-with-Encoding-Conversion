import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class FrameParsingTest {
    public static void main(String[] args) {
        // Two frames: ABC and D.
        var input = new ArrayList<>(List.of(
            "00", "03", "41", "42", "43",
            "00", "01", "44"
        ));

        // Test your existing frame extraction and byte conversion methods.
        byte[] first = encodingtaskClient.listToBytes(
            encodingtaskClient.listadding(0, 4, input));

        byte[] second = encodingtaskClient.listToBytes(
            encodingtaskClient.listadding(5, 7, input));

        if (!Arrays.equals(first, new byte[]{0, 3, 65, 66, 67}))
            throw new AssertionError("First frame incorrect");

        if (!Arrays.equals(second, new byte[]{0, 1, 68}))
            throw new AssertionError("Second frame incorrect");

        System.out.println("PASS: frame extraction and byte conversion");
    }
}