import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.nio.file.Path;

class DatabaseCheck {
    public static void main(String[] args) {
        String databasePath =
            Path.of("transactions.db").toAbsolutePath().toString();

        try (Connection connection =
                DriverManager.getConnection("jdbc:sqlite:" + databasePath)) {

            System.out.println("Database connected: " + databasePath);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}