import java.io.*;
import java.net.*;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Arrays;

class encodingTaskServer {

    public static int findNextOR(byte [] payload){  // this method is finding the next vertical line - | in the array. This is useful
                                                    // because it is going to help when separating types of transactions, transaction IDs, etc.
                                                    // in order to store them in the database

        int count = 0; // index at which the | is found
        int ORcount = 0;

        for (byte b: payload){
            int y = Byte.toUnsignedInt(b); // turns byte into a decimal

            if (y==124){ // 124 is the decimal for | in the ISO-8859-2
                ORcount++;
                break;
            }

            count++;
        }

        if (ORcount == 0){ // if there is no vertical line |:
            count = -1;
        }
        return count; // index of |
    }

    public static void main(String[] args) throws Exception{

    Connection connection = DriverManager.getConnection("jdbc:sqlite:transactions.db"); // Server and Java are connected through JDBC
    // First, a table for storing data is created:
    String createTableSQL = """ 
                CREATE TABLE IF NOT EXISTS transactions (

                id INTEGER PRIMARY KEY,
                transaction_type TEXT NOT NULL,
                transaction_id TEXT NOT NULL,
                amount TEXT NOT NULL,
                currency TEXT NOT NULL
            )
        
        """;

        try (Statement statement = connection.createStatement()) {
                statement.executeUpdate(createTableSQL);
        }

    int port = 4320;
    ServerSocket ss = new ServerSocket(port);

    System.out.println("Waiting for an incoming connection...");

    Socket s = ss.accept(); // once the potential connection is out, the server waits until client is connected
    
    // input and output pipelines are initialised
    DataInputStream dis = new DataInputStream(s.getInputStream());
    DataOutputStream dos = new DataOutputStream(s.getOutputStream());

    FileOutputStream f = new FileOutputStream("somefile.txt"); // flat file that received decoded payloads line-by-line
	DataOutputStream outp = new DataOutputStream(f);


    dos.writeUTF("Connection established"); // proof that the server and client are connected
    dos.flush();

    int x = dis.read(); // takes the first byte and converts it into int

    while (x != -1){ // it loops until it reaches the EOF

        int secondbyte = dis.readUnsignedByte(); // second byte in int
        int payloadLength = x*256 + secondbyte; // it is multiplied by 16^2, to move the first byte to 2nd and 3rd index
        byte[] payload = new byte[payloadLength]; // payload

        try {
            if (secondbyte == -1) { // Truncated header
                throw new IOException("Truncated header: second byte missing");
            }
            } catch (IOException e) {
                System.err.println(e.getMessage());
                break;
        }

        try {
            if (payloadLength == 0 || payloadLength > 4096) { // invalid payload length
                throw new IOException("Invalid payload length: " + payloadLength);
        }
    }catch (IOException e){
        System.err.println(e.getMessage());
        break;
    }

        try {
        dis.readFully(payload); // this takes payload amount of bytes in one bulk
        } catch (EOFException e) { // truncated payload
        throw new IOException(
            "Truncated payload: expected " + payloadLength + " bytes", e);
        }

       
        byte [] copyOfPayload = payload; // store variable of payload 
        int ORindex; // index of the next |
        int whichExecutionCount = 0; // keeps track where the each element belongs to - transaction type, transaction ID, Amount and currency
        String transactionType = null;
        String transactionID = null;
        String theAmount = null;
        String currency = null;
        

        while(copyOfPayload.length>0){ // we are looping over the payload to extract transaction type, transaction ID, Amount and currency by identifying the index of |
            int index1 = 0;
            ORindex = findNextOR(copyOfPayload); // index of the next | in a payload
            if (ORindex != -1){
                byte[] slice = Arrays.copyOfRange(copyOfPayload, index1, ORindex); // the slice up to a | index is taken
                index1 = ORindex + 1;
                String sliceText = new String(slice, Charset.forName("ISO-8859-2")); // the byte slice is converted into a string using ISO-8859-2 table
                whichExecutionCount++;
                copyOfPayload = Arrays.copyOfRange(copyOfPayload, index1, copyOfPayload.length); // the array is shortened by what was stored in slice

                if (whichExecutionCount == 1){ // the first is the transaction type
                    transactionType = sliceText;
                }

                if (whichExecutionCount == 2){ // the second one is the transaction ID
                    transactionID = sliceText;
                }

                if (whichExecutionCount == 3){ // the third one is the amount
                    theAmount = sliceText;
                }

            }

            else{ // since there is no | for the last element - currency, it is handled in a separate block
                currency = new String(copyOfPayload, Charset.forName("ISO-8859-2"));
                break;
            }
        }

        String updateSQLTable = """
        INSERT INTO transactions (transaction_type, transaction_id, amount, currency)
        VALUES (?, ?, ?, ?)
        """;

        if (whichExecutionCount == 3 // updating the SQL table with those new values
        && transactionType != null
        && transactionID != null
        && theAmount != null
        && currency != null) {

        try (PreparedStatement statement =
                connection.prepareStatement(updateSQLTable)) {

            statement.setString(1, transactionType);
            statement.setString(2, transactionID);
            statement.setString(3, theAmount);
            statement.setString(4, currency);

            statement.executeUpdate();
        }
    }

        String text = new String(payload, Charset.forName("ISO-8859-2")); // payload is converted to ISO-8859-2 
        outp.write((text + "\n").getBytes(java.nio.charset.StandardCharsets.UTF_8)); // ISO-8859-2 is converted to UTF-8 and stored in a .txt file 

        x = dis.read();

       }
    }
}