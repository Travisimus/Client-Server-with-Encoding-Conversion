import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.concurrent.TimeUnit;

class ClientServerTest {
    public static void main(String[] args) throws Exception {
        StringBuilder expected = new StringBuilder();

        try (var in = new DataInputStream(
                new FileInputStream("sample-input-ascii.bin"))) {
            while (in.available() > 0) {
                byte[] payload = new byte[in.readUnsignedShort()];
                in.readFully(payload);
                expected.append(new String(
                    payload, Charset.forName("ISO-8859-2"))).append("\n");
            }
        }

        Process server = new ProcessBuilder(
            "java", "-cp", ".;lib/*", "encodingTaskServer")
            .redirectErrorStream(true).start();

        try {
            var log = new BufferedReader(
                new InputStreamReader(server.getInputStream()));

            String line;
            do {
                line = log.readLine();
                if (line == null)
                    throw new AssertionError("Server failed to start");
            } while (!line.contains("Waiting for an incoming connection"));

            encodingtaskClient.main(new String[0]);

            if (!server.waitFor(15, TimeUnit.SECONDS))
                throw new AssertionError("Server timed out");

            if (server.exitValue() != 0)
                throw new AssertionError("Server failed");

            String actual = Files.readString(
                Path.of("somefile.txt"), StandardCharsets.UTF_8);

            if (!actual.equals(expected.toString()))
                throw new AssertionError("Output does not match input");

            System.out.println("PASS: client-to-server flow");
        } finally {
            server.destroy();
        }
    }
}